from PIL import Image
import numpy as np


def make_kernel(ksize, sigma):
    """
    Create a normalized Gaussian kernel.
    """
    kernel = np.zeros((ksize, ksize), dtype=np.float64)

    center = ksize // 2

    for y in range(ksize):
        for x in range(ksize):
            dx = x - center
            dy = y - center

            kernel[y, x] = (
                1.0 / (2 * np.pi * sigma ** 2)
                * np.exp(-(dx ** 2 + dy ** 2) / (2 * sigma ** 2))
            )

    # Normalize so that the kernel sums to 1
    kernel /= np.sum(kernel)

    return kernel


def slow_convolve(arr, k):
    """
    Convolution with zero-padding.
    Works for grayscale and RGB images.
    """
    k = np.flip(k)
    kh, kw = k.shape
    pad_h = kh // 2
    pad_w = kw // 2

    # Grayscale image
    if arr.ndim == 2:
        h, w = arr.shape

        padded = np.pad(
            arr,
            ((pad_h, pad_h), (pad_w, pad_w)),
            mode='constant',
            constant_values=0
        )

        result = np.zeros((h, w), dtype=np.float64)

        for i in range(h):
            for j in range(w):
                value = 0.0

                for u in range(kh):
                    for v in range(kw):
                        value += k[u, v] * padded[i + u, j + v]

                result[i, j] = value

        return result

    # RGB image
    elif arr.ndim == 3:
        h, w, c = arr.shape

        padded = np.pad(
            arr,
            ((pad_h, pad_h), (pad_w, pad_w), (0, 0)),
            mode='constant',
            constant_values=0
        )

        result = np.zeros((h, w, c), dtype=np.float64)

        for channel in range(c):
            for i in range(h):
                for j in range(w):
                    value = 0.0

                    for u in range(kh):
                        for v in range(kw):
                            value += k[u, v] * padded[i + u, j + v, channel]

                    result[i, j, channel] = value

        return result

    else:
        raise ValueError("Unsupported image shape")


if __name__ == '__main__':

    # Gaussian parameters (good starting point)
    k = make_kernel(5, 1.0)

    # Choose one image
    im = np.array(Image.open('data/input1.jpg'))

    # Blur image
    blurred = slow_convolve(im.astype(np.float64), k)

    # Unsharp masking
    mask = im.astype(np.float64) - blurred
    sharpened = im.astype(np.float64) + mask

    # Clip to valid image range
    sharpened = np.clip(sharpened, 0, 255)

    # Convert back to uint8
    sharpened = sharpened.astype(np.uint8)

    # Save result
    Image.fromarray(sharpened).save('sharpened.png')

    print("Saved sharpened image as sharpened.png")